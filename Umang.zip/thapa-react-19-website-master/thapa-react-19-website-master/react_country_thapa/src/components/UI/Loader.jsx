import "../../App.css";

export function Loader() {
  return (
    <div className="container loader-section">
      <div className="loader"></div>;
    </div>
  );
}
